use std::{error::Error, fs::File};

use bitors::TorrentBuilder;

fn main() -> Result<(), Box<dyn Error>> {
    let torrent = TorrentBuilder::from_path("/home/zaur/projects")?.build_v1()?;

    let mut file = File::create("new.torrent")?;
    torrent.to_bencode().encode_to_writer(&mut file)?;

    println!("{}", torrent.magnet_link());

    Ok(())
}
